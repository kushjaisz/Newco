package com.example.newco.HelperAdapter;

public class TrendingHelper {
    private int id;
    private String title;
    private String shortdesc;
    private String readmore;
    private String image;

    public TrendingHelper(int id, String title, String shortdesc, String readmore, String image) {
        this.id = id;
        this.title = title;
        this.shortdesc = shortdesc;
        this.readmore = readmore;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getShortdesc() {
        return shortdesc;
    }

    public String getReadmore() {
        return readmore;
    }

    public String getImage() {
        return image;
    }
}
