package com.example.newco.HelperAdapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class TrendingAdapter extends RecyclerView.Adapter<TrendingAdapter.ViewHolder> {

    private List<TrendingHelper> trendingHelperList;
    private Context context;
    public TrendingAdapter(Context context,List<TrendingHelper> trendingHelperList )
    {
        this.trendingHelperList = trendingHelperList;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.trending_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder myViewHolder, int position) {
        final TrendingHelper categories = trendingHelperList.get(position);
        myViewHolder.textViewTitle.setText(categories.getTitle());
        myViewHolder.textViewDec.setText(categories.getShortdesc());
        myViewHolder.textViewReadmore.setText(categories.getReadmore());

        Glide.with(myViewHolder.imageView).load(categories.getImage()).into(myViewHolder.imageView);

        myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",categories.getTitle());
                intent.putExtra("image",categories.getImage());
                intent.putExtra("des",categories.getShortdesc());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return trendingHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewTitle,textViewDec,  textViewReadmore;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDec = itemView.findViewById(R.id.textViewShortDesc);
            textViewReadmore = itemView.findViewById(R.id.textViewReadmore);

        }
    }
}
