package com.example.newco.Science;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.Cars.CarsAdapter;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class ScienceAdapter extends RecyclerView.Adapter<ScienceAdapter.ViewHolder> {

    private Context context;
    private List<ScienceHelper> scienceHelperList;
    public  ScienceAdapter(Context context, List<ScienceHelper> scienceHelperList)
    {
        this.context = context;
        this.scienceHelperList = scienceHelperList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. science_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final ScienceHelper scienceHelper = scienceHelperList.get(position);
        holder.scienceText.setText(scienceHelper.getTitle());
        holder.scienceDescription.setText(scienceHelper.getDescription());
        Glide.with(holder.scienceImageview).load(scienceHelper.getImage()).into(holder.scienceImageview);

        holder.scienceImageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",scienceHelper.getTitle());
                intent.putExtra("image",scienceHelper.getImage());
                intent.putExtra("des",scienceHelper.getDescription());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return scienceHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView scienceImageview;
        TextView scienceText,scienceDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            scienceImageview = itemView.findViewById(R.id.science_image);
            scienceText = itemView.findViewById(R.id.science_title);
            scienceDescription = itemView.findViewById(R.id.science_description);
        }
    }
}
