package com.example.newco.Religion;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.R;
import com.example.newco.Science.ScienceAdapter;
import com.example.newco.Science.ScienceHelper;
import com.example.newco.Science.Science_cat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Religion_cat extends AppCompatActivity {
    private  static final String Cars_URL = "http://192.168.1.3/newco/api/religion.php";
    RecyclerView recyclerView;
    Context context;
    List<Religion_helper> religion_helperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_religion_cat);
        religion_helperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.religion_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadreligion();
    }

    private void loadreligion() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Cars_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray religion = new JSONArray(response);

                    for (int i = 0; i<religion.length();i++)
                    {
                        JSONObject religionObject = religion.getJSONObject(i);

                        int id = religionObject.getInt("id");
                        String title = religionObject.getString("title");
                        String description = religionObject.getString("description");

                        String image = religionObject.getString("image");
                        Religion_helper e = new Religion_helper(id,title,description,image);
                        religion_helperList.add(e);
                    }
                    ReligionAdapter adapter = new ReligionAdapter(Religion_cat.this, religion_helperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Religion_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}