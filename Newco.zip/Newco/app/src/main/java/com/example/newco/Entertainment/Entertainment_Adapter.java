package com.example.newco.Entertainment;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.EntertainmentView;
import com.example.newco.R;
import com.example.newco.Sports.SportsAdapter;

import java.util.List;

public class Entertainment_Adapter extends RecyclerView.Adapter<Entertainment_Adapter.ViewHolder> {
    private Context context;
    private List<Entertainment_helper> entertainment_helperList;
    public Entertainment_Adapter(Context context,List<Entertainment_helper> entertainment_helperslist)
    {
        this.context = context;
        this.entertainment_helperList = entertainment_helperslist;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.entertainment_ct_crd, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
       final Entertainment_helper entertainment_helper = entertainment_helperList.get(position);
       holder.entertainment_text.setText(entertainment_helper.getEntertainment_title());
       holder.entertainment_description.setText(entertainment_helper.getEntertainment_description());

        Glide.with(holder.entertainment_image).load(entertainment_helper.getEntertainment_image()).into(holder.entertainment_image);

        holder.entertainment_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EntertainmentView.class);
                intent.putExtra("title",entertainment_helper.getEntertainment_title());
                intent.putExtra("image",entertainment_helper.getEntertainment_image());
                intent.putExtra("des",entertainment_helper.getEntertainment_description());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return entertainment_helperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView entertainment_image;
        TextView entertainment_text,entertainment_description;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            entertainment_description = itemView.findViewById(R.id.entertainment_description);
            entertainment_text = itemView.findViewById(R.id.entertainment_title);
            entertainment_image = itemView.findViewById(R.id.entertainment_image);
        }
    }
}
