package com.example.newco;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class HealthView extends AppCompatActivity {
    TextView title,description;
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_view);
        title = findViewById(R.id.healthv_title);
        image = findViewById(R.id.healthv_Image);
        description = findViewById(R.id.healthv_Description);

        Intent i = getIntent();
        String titlee = i.getStringExtra("title");
        String imagee = i.getStringExtra("image");
        String decc = i.getStringExtra("des");

        title.setText(titlee);
        description.setText(decc);
        Glide.with(title).load(imagee).into(image);
    }
}