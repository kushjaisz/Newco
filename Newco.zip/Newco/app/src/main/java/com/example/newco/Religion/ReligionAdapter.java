package com.example.newco.Religion;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.R;
import com.example.newco.Science.ScienceAdapter;
import com.example.newco.Trending_View;

import java.util.List;

public class ReligionAdapter extends RecyclerView.Adapter<ReligionAdapter.ViewHolder> {

    private Context context;
    private List<Religion_helper> religion_helperList;
    public ReligionAdapter(Context context,List<Religion_helper> religion_helperList)
    {
        this.context =context;
        this.religion_helperList = religion_helperList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. religion_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final  Religion_helper religion_helper = religion_helperList.get(position);
        holder.descriptionReligion.setText(religion_helper.getDescription());
        holder.titleReligion.setText(religion_helper.getTitle());
        Glide.with(holder.religionImage).load(religion_helper.getImage()).into(holder.religionImage);

        holder.religionImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",religion_helper.getTitle());
                intent.putExtra("image",religion_helper.getImage());
                intent.putExtra("des",religion_helper.getDescription());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return religion_helperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView religionImage;
        TextView titleReligion,descriptionReligion;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleReligion = itemView.findViewById(R.id.religion_title);
            descriptionReligion = itemView.findViewById(R.id.religion_description);
            religionImage = itemView.findViewById(R.id.religion_image);
        }
    }
}
