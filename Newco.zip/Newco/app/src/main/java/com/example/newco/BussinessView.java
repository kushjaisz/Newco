package com.example.newco;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class BussinessView extends AppCompatActivity {
    TextView title,description;
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bussiness_view);

        title = findViewById(R.id. bussinessv_title);
        image = findViewById(R.id.bussinessv_Image);
        description = findViewById(R.id.bussinessv_Description);

        Intent i = getIntent();
        String titlee = i.getStringExtra("title");
        String imagee = i.getStringExtra("image");
        String decc = i.getStringExtra("des");

        title.setText(titlee);
        description.setText(decc);
        Glide.with(title).load(imagee).into(image);
    }
}