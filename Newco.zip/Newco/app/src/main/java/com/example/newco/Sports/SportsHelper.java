package com.example.newco.Sports;

public class SportsHelper {
    int id;
    String sports_title;
    String sports_image;
    String sports_description;

    public SportsHelper(int id, String sports_title, String sports_image, String sports_description) {
        this.id = id;
        this.sports_title = sports_title;
        this.sports_image = sports_image;
        this.sports_description = sports_description;
    }

    public int getId() {
        return id;
    }

    public String getSports_title() {
        return sports_title;
    }

    public String getSports_image() {
        return sports_image;
    }

    public String getSports_description() {
        return sports_description;
    }
}
