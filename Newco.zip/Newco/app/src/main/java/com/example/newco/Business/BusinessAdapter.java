package com.example.newco.Business;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.Entertainment.Entertainment_Adapter;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class BusinessAdapter extends RecyclerView.Adapter<BusinessAdapter.ViewHolder> {
    private Context context;
    private List<BusinessHelper> businessHelperList;
    public BusinessAdapter(Context context,List<BusinessHelper> businessHelperList)
    {
        this.context = context;
        this.businessHelperList = businessHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. bussiness_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
         final BusinessHelper businessHelper = businessHelperList.get(position);
         holder.business_title.setText(businessHelper.getTitle());
         holder.business_description.setText(businessHelper.getDescription());

        Glide.with(holder.business_image).load(businessHelper.getImage()).into(holder.business_image);

        holder.business_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",businessHelper.getTitle());
                intent.putExtra("image",businessHelper.getImage());
                intent.putExtra("des",businessHelper.getDescription());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return businessHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView business_image;
        TextView business_title,business_description;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            business_image = itemView.findViewById(R.id.bussiness_image);
            business_title = itemView.findViewById(R.id.business_title);
            business_description = itemView.findViewById(R.id.business_description);
        }
    }
}
