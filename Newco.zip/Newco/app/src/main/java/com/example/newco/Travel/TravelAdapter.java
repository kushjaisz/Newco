package com.example.newco.Travel;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.Business.BusinessAdapter;
import com.example.newco.Business.BusinessHelper;
import com.example.newco.R;
import com.example.newco.TravelView;
import com.example.newco.Trending_View;

import java.util.List;

public class TravelAdapter extends RecyclerView.Adapter<TravelAdapter.ViewHolder> {
    private Context context;
    private List<TravelHelper> travelHelperList;
    public TravelAdapter(Context context,List<TravelHelper> travelHelperList)
    {
        this.context = context;
        this.travelHelperList = travelHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. travel_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final TravelHelper travelHelper = travelHelperList.get(position);
        holder.travelTitle.setText(travelHelper.getTitle());
        holder.travelDescription.setText(travelHelper.getDescription());

        Glide.with(holder.travelImage).load(travelHelper.getImage()).into(holder.travelImage);

        holder.travelImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, TravelView.class);
                intent.putExtra("title",travelHelper.getTitle());
                intent.putExtra("image",travelHelper.getImage());
                intent.putExtra("des",travelHelper.getDescription());
                context.startActivity(intent);
            }
        });





    }

    @Override
    public int getItemCount() {
        return travelHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView travelImage;
        TextView travelTitle;
        TextView travelDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            travelImage = itemView.findViewById(R.id.travel_image);
            travelTitle = itemView.findViewById(R.id.travel_title);
            travelDescription = itemView.findViewById(R.id.travel_description);
        }
    }
}
