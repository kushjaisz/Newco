package com.example.newco.Science;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Cars.CarsAdapter;
import com.example.newco.Cars.CarsHelper;
import com.example.newco.Cars.Cars_cat;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Science_cat extends AppCompatActivity {
    private  static final String Cars_URL = "http://192.168.1.3/newco/api/science.php";
    RecyclerView recyclerView;
    Context context;
    List<ScienceHelper> scienceHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_cat);

        scienceHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.science_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadscience();
    }

    private void loadscience() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Cars_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray science = new JSONArray(response);

                    for (int i = 0; i<science.length();i++)
                    {
                        JSONObject scienceObject = science.getJSONObject(i);

                        int id = scienceObject.getInt("id");
                        String title = scienceObject.getString("title");
                        String description = scienceObject.getString("description");

                        String image = scienceObject.getString("image");
                        ScienceHelper e = new ScienceHelper(id,title,image,description);
                        scienceHelperList.add(e);
                    }
                    ScienceAdapter adapter = new ScienceAdapter(Science_cat.this, scienceHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Science_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}