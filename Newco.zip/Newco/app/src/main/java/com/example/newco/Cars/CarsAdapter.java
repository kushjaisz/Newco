package com.example.newco.Cars;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.Business.BusinessAdapter;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class CarsAdapter extends RecyclerView.Adapter<CarsAdapter.ViewHolder> {
    private Context context;
    private List<CarsHelper> carsHelperList;

    public CarsAdapter(Context context,List<CarsHelper> carsHelpersList)
    {
        this.carsHelperList = carsHelpersList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. cars_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CarsHelper carsHelper = carsHelperList.get(position);
        holder.cars_title.setText(carsHelper.getTitle());
        holder.cars_description.setText(carsHelper.getDescription());

        Glide.with(holder.cars_image).load(carsHelper.getImage()).into(holder.cars_image);
        holder.cars_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",carsHelper.getTitle());
                intent.putExtra("image",carsHelper.getImage());
                intent.putExtra("des",carsHelper.getDescription());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return carsHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView cars_image;
        TextView cars_title, cars_description;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cars_image = itemView.findViewById(R.id.cars_image);
            cars_title = itemView.findViewById(R.id.cars_title);
            cars_description = itemView.findViewById(R.id.cars_description);
        }
    }
}
