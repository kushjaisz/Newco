package com.example.newco.Entertainment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.R;
import com.example.newco.Sports.SportsAdapter;
import com.example.newco.Sports.SportsHelper;
import com.example.newco.Sports.Sports_Cat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Entertainment_cat extends AppCompatActivity {
    private  static final String ENTERTAINMENT_URL = "http://192.168.1.3/newco/api/entertainment.php";
    RecyclerView recyclerView;
    Context context;
    List<Entertainment_helper> entertainment_helperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entertainment_cat);
        entertainment_helperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.entertainment_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadEntertainment();
    }

    private void loadEntertainment() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, ENTERTAINMENT_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray entertainment = new JSONArray(response);

                    for (int i = 0; i<entertainment.length();i++)
                    {
                        JSONObject entertainmentObject = entertainment.getJSONObject(i);

                        int id = entertainmentObject.getInt("id");
                        String title = entertainmentObject.getString("title");
                        String description = entertainmentObject.getString("description");

                        String image = entertainmentObject.getString("image");
                        Entertainment_helper e = new Entertainment_helper(id,title,description,image);
                        entertainment_helperList.add(e);
                    }
                    Entertainment_Adapter adapter = new Entertainment_Adapter(Entertainment_cat.this, entertainment_helperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Entertainment_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}