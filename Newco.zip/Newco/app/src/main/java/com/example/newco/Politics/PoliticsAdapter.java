package com.example.newco.Politics;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class PoliticsAdapter extends RecyclerView.Adapter<PoliticsAdapter.ViewHolder> {
    private Context context;
    private List<Politicshelper> politicsHelperList;
    public PoliticsAdapter(Context context,List<Politicshelper> politicsHelperList)
    {
        this.context = context;
        this.politicsHelperList = politicsHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. politics_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Politicshelper politicshelper= politicsHelperList.get(position);
        holder.politicsTitle.setText(politicshelper.getTitle());
        holder.politicsDescription.setText(politicshelper.getDescription());

        Glide.with(holder.politicsImage).load(politicshelper.getImage()).into(holder.politicsImage);

        holder.politicsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",politicshelper.getTitle());
                intent.putExtra("image",politicshelper.getImage());
                intent.putExtra("des",politicshelper.getDescription());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return politicsHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView politicsImage;
        TextView politicsTitle,politicsDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            politicsImage = itemView.findViewById(R.id.politics_image);
            politicsTitle = itemView.findViewById(R.id.politics_title);
            politicsDescription = itemView.findViewById(R.id.politics_description);
        }
    }
}
