package com.example.newco.Technology;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.R;
import com.example.newco.Science.ScienceAdapter;
import com.example.newco.Trending_View;

import java.util.List;

public class TechnologyAdapter extends RecyclerView.Adapter<TechnologyAdapter.ViewHolder> {
    private Context context;
    private List<TechnologyHelper> technologyHelperList;
    public TechnologyAdapter(Context context,List<TechnologyHelper> technologyHelperList)
    {
        this.context = context;
        this.technologyHelperList = technologyHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. technology_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
     final  TechnologyHelper technologyHelper = technologyHelperList.get(position);
     holder.techTitle.setText(technologyHelper.getTitle());
     holder.techDescription.setText(technologyHelper.getDescription());
        Glide.with(holder.techImage).load(technologyHelper.getImage()).into(holder.techImage);

        holder.techImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",technologyHelper.getTitle());
                intent.putExtra("image",technologyHelper.getImage());
                intent.putExtra("des",technologyHelper.getDescription());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return technologyHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView techImage;
        TextView techTitle,techDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            techImage = itemView.findViewById(R.id.technology_image);
            techTitle = itemView.findViewById(R.id.technology_title);
            techDescription = itemView.findViewById(R.id.technology_description);
        }
    }
}
