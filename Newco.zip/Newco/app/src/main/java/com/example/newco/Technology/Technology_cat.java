package com.example.newco.Technology;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Politics.PoliticsAdapter;
import com.example.newco.Politics.Politics_cat;
import com.example.newco.Politics.Politicshelper;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Technology_cat extends AppCompatActivity {
    private  static final String Politic_URL = "http://192.168.1.3/newco/api/tech.php";
    RecyclerView recyclerView;
    Context context;
    List<TechnologyHelper> technologyHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_technology_cat);
        technologyHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.technology_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadTech();
    }

    private void loadTech() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Politic_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray tech = new JSONArray(response);

                    for (int i = 0; i<tech.length();i++)
                    {
                        JSONObject techObject = tech.getJSONObject(i);

                        int id = techObject.getInt("id");
                        String title = techObject.getString("title");
                        String description = techObject.getString("description");

                        String image = techObject.getString("image");
                        TechnologyHelper e = new TechnologyHelper(id,title,description,image);
                        technologyHelperList.add(e);
                    }
                    TechnologyAdapter adapter = new TechnologyAdapter(Technology_cat.this, technologyHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Technology_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}