package com.example.newco.Health;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Business.BusinessAdapter;
import com.example.newco.Business.BusinessHelper;
import com.example.newco.Business.Business_cat;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Health_cat extends AppCompatActivity {
    private  static final String Health_URL = "http://192.168.1.3/newco/api/health.php";
    RecyclerView recyclerView;
    Context context;
    List<HealthHelper> healthHelpersList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_cat);

        healthHelpersList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.health_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadHealth();
    }

    private void loadHealth()
    {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Health_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray health = new JSONArray(response);

                    for (int i = 0; i<health.length();i++)
                    {
                        JSONObject healthObject = health.getJSONObject(i);

                        int id = healthObject.getInt("id");
                        String title = healthObject.getString("title");
                        String description = healthObject.getString("description");

                        String image = healthObject.getString("image");
                        HealthHelper e = new HealthHelper(id,title,image,description);
                        healthHelpersList.add(e);
                    }
                    HealthAdapter adapter = new HealthAdapter(Health_cat.this, healthHelpersList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Health_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}