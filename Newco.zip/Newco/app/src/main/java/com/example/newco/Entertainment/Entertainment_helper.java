package com.example.newco.Entertainment;

public class Entertainment_helper {
    int id;
    String entertainment_title;
    String entertainment_description;
    String entertainment_image;

    public Entertainment_helper(int id, String entertainment_title, String entertainment_description, String entertainment_image) {
        this.id = id;
        this.entertainment_title = entertainment_title;
        this.entertainment_description = entertainment_description;
        this.entertainment_image = entertainment_image;
    }

    public int getId() {
        return id;
    }

    public String getEntertainment_title() {
        return entertainment_title;
    }

    public String getEntertainment_description() {
        return entertainment_description;
    }

    public String getEntertainment_image() {
        return entertainment_image;
    }
}
