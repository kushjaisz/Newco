package com.example.newco.Cars;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Business.BusinessAdapter;
import com.example.newco.Business.BusinessHelper;
import com.example.newco.Business.Business_cat;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Cars_cat extends AppCompatActivity {
    private  static final String Cars_URL = "http://192.168.1.3/newco/api/cars.php";
    RecyclerView recyclerView;
    Context context;
    List<CarsHelper> carsHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars_cat);
        carsHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.cars_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadcars();
    }

    private void loadcars() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Cars_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray cars = new JSONArray(response);

                    for (int i = 0; i<cars.length();i++)
                    {
                        JSONObject carsObject = cars.getJSONObject(i);

                        int id = carsObject.getInt("id");
                        String title = carsObject.getString("title");
                        String description = carsObject.getString("description");

                        String image = carsObject.getString("image");
                        CarsHelper e = new CarsHelper(id,title,description,image);
                        carsHelperList.add(e);
                    }
                    CarsAdapter adapter = new CarsAdapter(Cars_cat.this, carsHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Cars_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}