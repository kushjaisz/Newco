package com.example.newco.World;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.R;
import com.example.newco.Religion.ReligionAdapter;
import com.example.newco.Religion.Religion_cat;
import com.example.newco.Religion.Religion_helper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class World_cat extends AppCompatActivity {
    private  static final String Cars_URL = "http://192.168.1.3/newco/api/world.php";
    RecyclerView recyclerView;
    Context context;
    List<WorldHelper> worldHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_world_cat);
        worldHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.world_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadworld();
    }

    private void loadworld() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Cars_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray world = new JSONArray(response);

                    for (int i = 0; i<world.length();i++)
                    {
                        JSONObject worldObject = world.getJSONObject(i);

                        int id = worldObject.getInt("id");
                        String title = worldObject.getString("title");
                        String description = worldObject.getString("description");

                        String image = worldObject.getString("image");
                        WorldHelper e = new WorldHelper(id,title,description,image);
                        worldHelperList.add(e);
                    }
                    WorldAdapter adapter = new WorldAdapter(World_cat.this, worldHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(World_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}