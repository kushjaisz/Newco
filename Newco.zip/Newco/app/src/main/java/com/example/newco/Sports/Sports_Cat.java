package com.example.newco.Sports;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.HelperAdapter.TrendingAdapter;
import com.example.newco.HelperAdapter.TrendingHelper;
import com.example.newco.MainActivity;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Sports_Cat extends AppCompatActivity {
    private  static final String SPORTS_URL = "http://192.168.1.3/newco/api/sports.php";
RecyclerView recyclerView;
Context context;
List<SportsHelper> sportsHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports__cat);

        sportsHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.sports_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadProduct();
    }

    private void loadProduct() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, SPORTS_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray sports = new JSONArray(response);

                    for (int i = 0; i<sports.length();i++)
                    {
                        JSONObject sportObject = sports.getJSONObject(i);

                        int id = sportObject.getInt("id");
                        String title = sportObject.getString("title");
                        String description = sportObject.getString("description");

                        String image = sportObject.getString("image");
                        SportsHelper sportsHelper = new SportsHelper(id,title,image,description);
                        sportsHelperList.add(sportsHelper);
                    }
                    SportsAdapter adapter = new SportsAdapter(Sports_Cat.this, sportsHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Sports_Cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
    }
