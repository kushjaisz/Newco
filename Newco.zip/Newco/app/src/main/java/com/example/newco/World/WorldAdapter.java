package com.example.newco.World;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.R;
import com.example.newco.Religion.ReligionAdapter;
import com.example.newco.Trending_View;

import java.util.List;

public class WorldAdapter extends RecyclerView.Adapter<WorldAdapter.ViewHolder> {
    private Context context;
    private List<WorldHelper> worldHelperList;
    public WorldAdapter(Context context,List<WorldHelper> worldHelperList)
    {
        this.context = context;
        this.worldHelperList = worldHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. world_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
         final WorldHelper worldHelper = worldHelperList.get(position);
         holder.worldTitle.setText(worldHelper.getTitle());
         holder.worldDescription.setText(worldHelper.getDescription());
        Glide.with(holder.worldImage).load(worldHelper.getImage()).into(holder.worldImage);

        holder.worldImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Trending_View.class);
                intent.putExtra("title",worldHelper.getTitle());
                intent.putExtra("image",worldHelper.getImage());
                intent.putExtra("des",worldHelper.getDescription());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return worldHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView worldImage;
        TextView worldTitle,worldDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            worldDescription = itemView.findViewById(R.id.world_description);
            worldTitle = itemView.findViewById(R.id.world_title);
            worldImage = itemView.findViewById(R.id.world_image);
        }
    }
}
