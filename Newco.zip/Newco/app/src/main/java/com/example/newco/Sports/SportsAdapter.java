package com.example.newco.Sports;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.HelperAdapter.TrendingAdapter;
import com.example.newco.R;
import com.example.newco.SportsView;
import com.example.newco.Trending_View;

import java.util.List;

public class SportsAdapter extends RecyclerView.Adapter<SportsAdapter.ViewHolder> {

    private Context context;
    private List<SportsHelper> sportsHelperList;

    public SportsAdapter (Context context, List<SportsHelper> sportsHelperList)
    {
        this.context = context;
        this.sportsHelperList = sportsHelperList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.sports_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
         final  SportsHelper sportsHelper = sportsHelperList.get(position);
         holder.sports_title.setText(sportsHelper.getSports_title());
         holder.sports_description.setText(sportsHelper.getSports_description());

        Glide.with(holder.sports_image).load(sportsHelper.getSports_image()).into(holder.sports_image);

        holder.sports_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, SportsView.class);
                intent.putExtra("title",sportsHelper.getSports_title());
                intent.putExtra("image",sportsHelper.getSports_image());
                intent.putExtra("des",sportsHelper.getSports_description());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sportsHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView sports_image;
        TextView sports_title,sports_description;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            sports_image = itemView.findViewById(R.id.sports_image);
            sports_title = itemView.findViewById(R.id.sports_title);
            sports_description = itemView.findViewById(R.id.sports_description);

        }
    }
}
