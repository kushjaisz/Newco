package com.example.newco;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Business.Business_cat;
import com.example.newco.Cars.Cars_cat;
import com.example.newco.Entertainment.Entertainment_cat;
import com.example.newco.Health.Health_cat;
import com.example.newco.HelperAdapter.TrendingAdapter;
import com.example.newco.HelperAdapter.TrendingHelper;
import com.example.newco.Politics.Politics_cat;
import com.example.newco.Religion.Religion_cat;
import com.example.newco.Science.Science_cat;
import com.example.newco.SessionManager.SessionManager;
import com.example.newco.Sports.Sports_Cat;
import com.example.newco.Technology.Technology_cat;
import com.example.newco.Travel.Travel_cat;
import com.example.newco.World.World_cat;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private  static final String Trending_URL = "http://192.168.1.3/newco/api/trending.php";


    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    ImageView menu;

    RecyclerView recyclerView;
    TrendingAdapter adapter;

    CardView sports,entertainment,business,cars,health,travel,politics,science,technology,world,religion;
    Context context;
    List<TrendingHelper> trendingHelperList;

    TextView name;
    Button logout;
    SessionManager sessionManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // for hiding toolbar or can say action bar
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        trendingHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.trending_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        loadProduct();

        menu = findViewById(R.id.menu);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);




        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.Open,R.string.Close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        sports = findViewById(R.id.cat_sport);
        entertainment = findViewById(R.id.cat_enter);
        business = findViewById(R.id.cat_business);
        cars = findViewById(R.id.cat_cars);
        health = findViewById(R.id.cat_health);
        travel = findViewById(R.id.cat_travel);
        politics = findViewById(R.id.cat_politics);
        science = findViewById(R.id.cat_science);
        technology = findViewById(R.id.cat_technology);
        world = findViewById(R.id.cat_world);
        religion = findViewById(R.id.cat_religion);
        name = findViewById(R.id.nameee);

        sessionManager = new SessionManager(this);
        sessionManager.checkLOGING();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String mUSername = user.get(sessionManager.USERNAME);
        String mPassword = user.get(sessionManager.PASSWORD);
        name.setText(mUSername);
      

        sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Sports_Cat.class);
                startActivity(intent);
            }
        });

        entertainment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Entertainment_cat.class);
                startActivity(intent);
            }
        });

        business.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Business_cat.class);
                startActivity(intent);
            }
        });

        cars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Cars_cat.class);
                startActivity(intent);
            }
        });

        health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Health_cat.class);
                startActivity(intent);
            }
        });


        travel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Travel_cat.class);
                startActivity(intent);
            }
        });

        politics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Politics_cat.class);
                startActivity(intent);
            }
        });

        science.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Science_cat.class);
                startActivity(intent);
            }
        });

        technology.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Technology_cat.class);
                startActivity(intent);
            }
        });

        world.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, World_cat.class);
                startActivity(intent);
            }
        });

        religion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Religion_cat.class);
                startActivity(intent);
            }
        });

    }


    private void loadProduct() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Trending_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray products = new JSONArray(response);

                    for (int i = 0; i<products.length();i++)
                    {
                        JSONObject productObject = products.getJSONObject(i);

                        int id = productObject.getInt("id");
                        String title = productObject.getString("title");
                        String description = productObject.getString("description");
                        String readmore = productObject.getString("readmore");
                        String image = productObject.getString("image");
                        TrendingHelper product = new TrendingHelper(id,title,description,readmore,image);
                        trendingHelperList.add(product);
                    }
                    TrendingAdapter adapter = new TrendingAdapter(MainActivity.this, trendingHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.SPORTS:
                Intent intent = new Intent(getApplicationContext(), Sports_Cat.class);
                startActivity(intent);
                break;
            case R.id.ENTERTAINMENT:
                Intent i = new Intent(getApplicationContext(), Entertainment_cat.class);
                startActivity(i);
                break;

            case R.id.BUSINESS:
                Intent b = new Intent(getApplicationContext(), Business_cat.class);
                startActivity(b);
                break;
            case R.id.CARS:
                Intent c = new Intent(getApplicationContext(), Cars_cat.class);
                startActivity(c);
                break;
            case R.id.HEALTH:
                Intent h = new Intent(getApplicationContext(), Health_cat.class);
                startActivity(h);
                break;
            case R.id.TRAVEL:
                Intent t = new Intent(getApplicationContext(), Travel_cat.class);
                startActivity(t);
                break;
            case R.id.POLITICS:
                Intent p = new Intent(getApplicationContext(), Politics_cat.class);
                startActivity(p);
                break;
            case R.id.SCIENCE:
                Intent s = new Intent(getApplicationContext(), Science_cat.class);
                startActivity(s);
                break;
            case R.id.TECHNOLOGY:
                Intent te = new Intent(getApplicationContext(), Technology_cat.class);
                startActivity(te);
                break;
            case R.id.WORLD:
                Intent w = new Intent(getApplicationContext(), World_cat.class);
                startActivity(w);
                break;
            case R.id.RELIGION:
                Intent r = new Intent(getApplicationContext(), Religion_cat.class);
                startActivity(r);
                break;

            case R.id.LOGOUT:
                sessionManager.logout();
                break;

        }
        return true;
    }
}