package com.example.newco.Business;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.newco.Entertainment.Entertainment_Adapter;
import com.example.newco.Entertainment.Entertainment_cat;
import com.example.newco.Entertainment.Entertainment_helper;
import com.example.newco.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Business_cat extends AppCompatActivity {
    private  static final String Bussiness_URL = "http://192.168.1.3/newco/api/business.php";
    RecyclerView recyclerView;
    Context context;
    List<BusinessHelper> businessHelperList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_cat);
        businessHelperList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.business_RV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadBusiness();
    }

    private void loadBusiness() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Bussiness_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray bussiness = new JSONArray(response);

                    for (int i = 0; i<bussiness.length();i++)
                    {
                        JSONObject businessObject = bussiness.getJSONObject(i);

                        int id = businessObject.getInt("id");
                        String title = businessObject.getString("title");
                        String description = businessObject.getString("description");

                        String image = businessObject.getString("image");
                        BusinessHelper e = new BusinessHelper(id,title,description,image);
                        businessHelperList.add(e);
                    }
                    BusinessAdapter adapter = new BusinessAdapter(Business_cat.this, businessHelperList);

                    //setting adapter to recyclerview
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Business_cat.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}