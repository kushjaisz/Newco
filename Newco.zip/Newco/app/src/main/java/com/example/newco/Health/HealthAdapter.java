package com.example.newco.Health;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.newco.Business.BusinessAdapter;
import com.example.newco.HealthView;
import com.example.newco.R;
import com.example.newco.Trending_View;

import java.util.List;

public class HealthAdapter extends RecyclerView.Adapter<HealthAdapter.ViewHolder> {
    private Context context;
    private List<HealthHelper> healthHelperList;
    public HealthAdapter(Context context,List<HealthHelper> healthHelperList)
    {
        this.context = context;
        this.healthHelperList = healthHelperList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout. health_cat_card, null);
        ViewHolder myViewHolder = new ViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final HealthHelper healthHelper = healthHelperList.get(position);
        holder.healthTitle.setText(healthHelper.getTitle());
        holder.healthDescription.setText(healthHelper.getDescription());

        Glide.with(holder.healthImage).load(healthHelper.getImage()).into(holder.healthImage);

        holder.healthImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, HealthView.class);
                intent.putExtra("title",healthHelper.getTitle());
                intent.putExtra("image",healthHelper.getImage());
                intent.putExtra("des",healthHelper.getDescription());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return healthHelperList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView healthImage;
        TextView healthTitle,healthDescription;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            healthImage = itemView.findViewById(R.id.health_image);
            healthTitle = itemView.findViewById(R.id.health_title);
            healthDescription = itemView.findViewById(R.id.health_description);
        }
    }
}
